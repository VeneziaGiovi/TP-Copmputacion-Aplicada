 poweroff
 poweroff
hostnamectl set-hostname TPServer
apt-get install openssh-server
apt update
poweroff
apt install mariadb-server
/etc/network/interfaces
sudo nano /etc/network/interfaces
poweroff
sudo nano /etc/network/interfaces
fdisk -l
poweroff
/etc/shh/sshd_config
nano /etc/ssh/sshd_config
cp /ruta/a/index.php /var/www/html/
vi /etc/ssh/sshd_config
poweroff
ls -l
ls
ls -la
mkdir -p /root/ .ssh
chmod 700 /root/ .ssh
vi /etc/ssh/sshd_config
vi /etc/ssh/sshd_config 
apt purge ssh 
apt install ssh
apt update
apt upgrate
apt upgrade 
vi /etc/ssh/sshd_config 
vi /etc/ssh/sshd_config 
systemctl restart ssh
ip --brief a
poweroff
ip --brief a
poweroff
wget http://192.168.1.52:8000/clave_publica.pub
wget http://192.168.1.52:8000/clave-ssh/clave_publica.pub
wget http://192.168.1.52:8000/clave-ssh/clave_publica.pub
wget http://192.168.1.52:8000/clave-ssh/clave_publica
wget http://192.168.1.52:8000/clave_publica.pub
ip a
wget http://192.168.1.52:8000/clave_publica.pub
wget http://192.168.1.52:8000/clave_publica.pub
wget http://192.168.1.52:8000/clave-ssh/clave_publica
wget http://192.168.1.52:8000/clave_publica.pub
status ssh
estatus ssh
poweroff
apt update
apt install -y virtualbox-guest-utils
apt install build-essential dkms linux-headers-$(uname -r)
poweroff
systemctl enable ssh
systemctl start ssh
systemctl status
mount -t vboxsf clave-ssh /mnt
ls /mtn/}
ls /mtn/
ls /mnt/
cat /mnt/clave_publica.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys 
cat /root/.ssh/authorized_keys 
systemctl status ssh
ufw allow ssh
poweroff
/etc/ssh/sshd_config
cat /root/.ssh/authorized_keys 
/etc/ssh/sshd_config
sudo cat /etc/ssh/sshd_config
sudo nano /etc/ssh/sshd_config
sudo vi /etc/ssh/sshd_config
sudo vi /etc/ssh/sshd_config
ip --brief a
/etc/ssh/sshd_config
ipconfig
ip a
ip --brief a
php -v
systemctl status apache2
a2enmod php7.3
sudo apt-cache search php
a2enmod php
sudo a2enmod php
php -v
sudo apt install php7.3 php7.3-cli php7.3-fmp php7.3-mysql libapache2-mod-php7.3
sudo add-apt-repository ppa:ondrej/php
 add-apt-repository ppa:ondrej/php
sudo apt update
sudo apt-cache search php
sudo nano /etc/apt/sources.list
sudo vi /etc/apt/sources.list
sudo apt install apache2
sudo systemctl status apache 2
apt insall apache2
apt install apache2
systemctl status apache2
apt install php
echo "<?php phpinfo(); ?>" | sudo tee /var/www/html/index.php
sudo chmod 644 /var/www/html/index.php
chmod 644 /var/www/html/index.php
ip a
systemctl start mariadb
systemctl enable mariadb
mariadb
cat /root/db.sql
ls -l /root/
cat /root/db.sql
mariadb
poweroff
ip show enp0s3
ip addr show enp0s3
ping -c 4 194.168.1.1
ping -c 4 8.8.8.8
ping -c 4 google.com
vi /etc/network/interfaces 
poweroff
ip link show+
ip link show
poweroff
/etc/ssh/sshd_config
ip a
php -v
/etc/apache2/mods-enabled/dir.conf
vi /etc/apache2/mods-enabled/dir.conf
systemctl restart apache2
/var/www/html/index.php
http://localhost
systemctl status apache2
ip a
poweroff
ufw disable
vi ufw disable
curl http://localhost
curl http://localhost
ls -l /var/www/html
chown -r www-data:www-data /var/www/html
chmod -R www-data:www-data /var/www/html
chmod -R 755 /var/www/html
ls -l /var/www/html
clear
ls -l /var/www/html
mv /var/www/html/'index (1).php' /var/www/html/index.php
/etc/apache2/apache2.conf
vi /etc/apache2/apache2.conf
/etc/apache2/mods-enabled/dir.conf
vi /etc/apache2/mods-enabled/dir.conf
systemctl restart apache2
ip a
chown -R www-data:www-data /var/www/html
chmod -R 755 /var/www/html
systemctl restart apache2
ls -l /var/html
ls -l /var/www/html
cat /var/www/html/index.php
mariadb -u root
ls /root
ls /root/
mariadb -u root < /root/db.sql
mariadb -u root
/var/www/html/index.php
clear
/var/www/html/index.php
chmod -R 755 /var/www/html
chmod -R 755 /var/www
chmod 755 /var/www
chmod 755 /var
vi /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
clear
systemctl restart apache2
apachectl configtest
vi /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
/var/www/html/index.php
vi /var/www/html/index.php
mariadb -u lcars -p
ls -l /var/www/html/logo.png
vi /var/www/html/index.php
vi /var/www/html/index.php
apt install php-mysqli
systemctl restart apache2
vi /etc/apache2/sites-available/000-default.conf
mariadb -u root
vi /etc/network/interfaces
poweroff
fdisk /dev/sdb
lsblk
vi /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
crontab -e
poweroff
poweroff
mkdir -p /opt/entregables
tar -czvf /opt/entregables/root.tar.gz /root
ip -a
ip a
tar -czvf /opt/entregables/etc.tar.gz /etc
tar -czvf /opt/entregables/opt.tar.gz /opt
tar -czvf /opt/entregables/proc.tar.gz /proc
ls -lh /opt/entregables/
mkdir -p /tmp/proc_copy
cp -r /proc/* /tmp/proc_copy 2>/dev/null
tar -czvf /opt/entregables/proc.tar.gz -C /tmp proc_copy
tar -vzvf /opt/entregables/www_dir.tar.gz /www.dir
tar -czvf /opt/entregables/www_dir.tar.gz /www.dir
tar -czvf /opt/entregables/www_dir.tar.gz /www_dir
tar -czvf /opt/entregables/backup_dir.tar.gz /backup_dir
tar -czvf - /var | split -b 50M - /opt/entregables/var.tar.gz.part.
poweroff
ip a
vi fdisk /dev/sdc
clear
fdisk /dev/sdc
poweroff
hostnamectl set-hostname TPServer
cat /etc/hostname
grep 127.0.1.1 /etc/hosts
vim /etc/hosts
grep 127.0.1.1 /etc/hosts
ping -c 3 deb.debian.org
di
ping -c 3 deb.debian.org
ip a 
ping -c 3 8.8.8.8
ip addr flush dev enp0s3
dhclient enp0s3
ip a
ping -c 3 deb.debian.org
cp /etc/apt/sources.list /etc/apt/sources.list.bak
vim /etc/apt/sources.list
apt update
apt install -y openssh-server apache2 php libapache2-mod-php php-mysql mariadb-server
php -v
systemctl is active ssh apache2 mariadb 
systemctl is-active ssh apache2 mariadb 
ss -tlnp
vim /etc/ssh/sshd_config
systemctl restart ssh
mkdir -p /root/.ssh
chmod 700 /root/.ssh
cat /root/clave_publica.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
vim /etc/ssh/sshd_config
systemctl restart ssh
exit
ssh -p 2222 root@127.0.0.1
ssh -i clave_privada.txt -p 2222 root@127.0.0.1
mysql -u root < /root/db.sql
mysql -u root -e "SHOW DATABASES;"
mysql -u root -e "USE ingenieria; SHOW TABLES;"
mysql -u root -e "SELECT user, host FROM mysql.user;




wq
wq!
mysql -u root -e "SELECT user, host FROM mysql.user;"
exit
cat /etc/network/interfaces
reboot
ip a
ping -c 3 192.168.1.1
ping -c deb.debian.org
ping -c 3 deb.debian.org
ping -c 3 8.8.8.8
cat /etc/resolv.conf
echo "nameserver 8.8.8.8" > /etc/resolv.conf
ping -c 3 deb.debian.org
poweroff
lsblk
cat /etc/fstab
blkid /dev/sdc1 /dev/sdc2
df -h | grep dir
fdisk -l /dev/sdc
cat /proc/partitions > /proc/particion
cat /proc/partitions > /root/particion
cat /root/particion
cp /root/index.php /root/logo.png /wwwww_dir/
ls -ld /www_dir
cp /root/index.php /root/logo.png /wwww_dir/
cp /root/index.php /root/logo.png /www_dir/
ls -l /www-dir/
ls -l /www_dir/
vim /etc/apache2/apache2.conf
vim /etc7apache2/sites-available/000-default.conf
vim /etc/apache2/sites-available/000-default.conf
gep DocumentRoot /etc/apache2/sites-available/000-default.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
grep -A4 "www_dir" /etc/apache2/apache2.conf
cp /root7index.php 7root/logo.png /www_dir/
cp /root/index.php /root/logo.png /www_dir/
ls -l /www_dir/
apachectl configtest
systemctl restart apache2
poweroff
