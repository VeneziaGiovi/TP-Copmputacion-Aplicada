#!/bin/bash 
# Backup de un directorio: Backup_full.sh <origen> <destino>

if [ "$1" = "-help" ]; then
    echo "Uso: backup_full.sh <origen> <destino>"
    echo "Ejemplo: backup_full.sh /var/log /backup_dir"
    exit 0
fi

if [ $# -ne 2 ]; then
	echo "Error: faltan argumentos. Use -help."
	exit 1
fi 

if [ ! -d "$1" ]; then
	echo "Error: el origen $1 no esta disponible"
	exit 1
fi

if ! mountpoint -q "$2"; then
	echo "Error: el destino $2 no esta montado"
	exit 1 
fi

NOMBRE=$( basename "$1")
FECHA=$(date +%Y%m%d) 
tar -czf "$2/${NOMBRE}_bkp_${FECHA}.tar.gz" "$1"
echo "Backup creado: $2/${NOMBRE}_bkp_${FECHA}.tar.gz" 







